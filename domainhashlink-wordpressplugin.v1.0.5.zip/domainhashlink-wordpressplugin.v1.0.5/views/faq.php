<h3><?php echo DHLOutput::_e('FAQ'); ?></h3>
<iframe src="<?php echo DHL_FAQ; ?>" width="100%" height="600" />