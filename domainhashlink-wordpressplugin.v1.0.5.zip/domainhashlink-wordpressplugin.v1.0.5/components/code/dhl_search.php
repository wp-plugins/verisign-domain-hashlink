search
<div>
	<!--<label for="dhl_search_box">Search for:</label>-->
	<input type="text" value="" name="dhl_search_box" id="<?php echo $dhl_field; ?>">
	<input type="submit" id="<?php echo $dhl_button; ?>" value="Search">
</div>